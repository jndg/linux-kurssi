# h1-Oma-Linux
Installing Debian on a virtual pc
